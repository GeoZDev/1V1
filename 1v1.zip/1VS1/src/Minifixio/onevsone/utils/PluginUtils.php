<?php

namespace Minifixio\onevsone\utils;

use pocketmine\Server;
use pocketmine\utils\TextFormat;


/**
 * Utility methods for my plugin
 */
class PluginUtils{
	
	/**
	 * Log on the server console
	 */
	public static function logOnConsole($message){
		$logger = Server::getInstance()->getLogger();
		$logger->info("§7[§d1vs1§7] " . $message);
	}

	public static function sendDefaultMessage($player, $message){
		$player->sendMessage(TextFormat::GOLD . "§7[§d1vs1§7] " . TextFormat::WHITE . $message);
	}
}



